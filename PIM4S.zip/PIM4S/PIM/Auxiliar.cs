﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIM
{
    public class Auxiliar
    {

        public static String CPF;

        public static string CNPJ;

        public static string conexaoBD = "Data Source=DESKTOP-76HMS08\\SQLEXPRESS;Initial Catalog=BDPIMEXPRESS;Persist Security Info=True;User ID=sa;Password=leo123";
    }
}

﻿namespace PIM
{


    partial class dbloginDataSet
    {
    }
}
